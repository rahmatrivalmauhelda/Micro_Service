package com.rahmat.auth.model;


public class User {

    private String username;
    private String password;

    // constructor kosong (wajib untuk Spring)
    public User() {}

    // constructor
    public User(String username, String password) {
        this.username = username;
        this.password = password;
    }

    // getter & setter
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }
}
